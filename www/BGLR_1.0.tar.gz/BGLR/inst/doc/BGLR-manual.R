### R code from vignette source 'BGLR-manual.Rnw'

