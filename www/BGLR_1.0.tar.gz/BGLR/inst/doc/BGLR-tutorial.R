### R code from vignette source 'BGLR-tutorial.Rnw'

